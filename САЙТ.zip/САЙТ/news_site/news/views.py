from django.shortcuts import render
from .models import Article
# Create your views here.

def index(request):
    articles = Article.objects.al().order_by('-created_at')
    return render(request, 'news/index.html',{'articles': articles})

def article_detail(request, article_id):
    article = Article.objects.get(id=article_id)
    return render(request, 'news/article_detail.html', {'article': article})
